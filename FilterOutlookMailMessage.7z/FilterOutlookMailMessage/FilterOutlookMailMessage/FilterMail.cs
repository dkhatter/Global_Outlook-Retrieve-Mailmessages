﻿using System.ComponentModel;
using System.Collections.Generic;
using System.Reflection;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Activities;
using System.Net.Mail;
using System;
using Microsoft.Office.Interop.Outlook;
using System.Linq;
using System.Activities.Expressions;
using System.IO;
using System.Activities.Statements;
using System.Runtime.InteropServices;

namespace OutlookActivity
{
    public class FilterMail : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        [DisplayName("Account Name")]
        [Description("Account from which mail messages need to be retreived")]
        public InArgument<string> Account { get; set; }

        [Category("Input")]
        [DisplayName("Folder Name")]
        [Description("Name of the mail folder from which mail messages need to be retreived.Nested folder can also be specifed. For example, Input\\Test ")]
        [RequiredArgument]
        public InArgument<string> Foldername { get; set; }


        [Category("Options")]
        [DisplayName("Only Unread mails")]
        [Description("Specifies whether to read only unread messages. By Default,it is set to false.")]
        [DefaultValue(false)]
        public bool Unread { get; set; }

        [Category("Options")]
        [DisplayName("Mark As Read")]
        [Description("Specifies whether the retreived messages should be marked as read. By default, it is set to false.")]
        [DefaultValue(false)]
        public bool MarkAsRead { get; set; }


        [Category("Options")]
        [DisplayName("Exact match for Subject")]
        [Description("Specifies whether input specified in Subject field should be matched exactly with the subject of emails in mailbox. By Default,it is set to false.")]
        [DefaultValue(false)]
        public bool ExactMatch_Subject { get; set; }

        [Category("Options")]
        [DisplayName("Subject")]
        [Description("Retrieves all the mails which contains the specified input in subject line")]
        [DefaultValue(null)]
        public InArgument<string> Subject { get; set; }


        [Category("Options")]
        [DisplayName("Body")]
        [Description("Retrieves all the mails which contains the specified input in body of mail message")]
        [DefaultValue(null)]
        public InArgument<string> Body { get; set; }

        [Category("Options")]
        [DisplayName("Sender Email Address")]
        [Description("Retrieves all the mails received from the specified email address")]
        [DefaultValue(null)]
        public InArgument<string> Sender { get; set; }

        [Category("Options")]
        [DisplayName("Receipent Email Address")]
        [Description("Retrieves all the mails sent to specified email address")]
        [DefaultValue(null)]
        public InArgument<string> Receipent { get; set; }

        [Category("Options")]
        [DisplayName("Start Date")]
        [Description("Retrieves all the mails with the date between specified Start Date and End Date parameters. If End Date input is not specified, all the mails till current date are retrieved.Specify input date string in the format yyyy-MM-dd hh:mm:ss. If time is not specified, default time is added as 00:00:00")]
        [DefaultValue(null)]
        public InArgument<string> FromDate { get; set; }

        [Category("Options")]
        [DisplayName("End Date")]
        [Description("Retrieves all the mails with the date between specified Start Date and End Date parameters. If Start Date input is not specified, all the mails till specified end date are retrieved.Specify input date string in the format yyyy-MM-dd hh:mm:ss. If time is not specified, default time is added as 23:59:59")]
        [DefaultValue(null)]
        public InArgument<string> ToDate { get; set; }

        [Category("Output")]
        [DisplayName("Mail Messages")]
        [Description("Retrieved mail messages as a collection of MailMessage objects")]
        public OutArgument<List<MailMessage>> MailMessages { get; set; }


        Outlook.NameSpace outlookNameSpace;
        Outlook.Application outlookApp;
        Outlook.MAPIFolder referencedFolder;
        Outlook.Items items;
        List<MailMessage> ListRetrievedMailMessage = new List<MailMessage>();
        Outlook.MailItem oitem;
        object mailobj;

        protected override void Execute(CodeActivityContext context)
        {
            try
            {
                string account = this.Account.Get((ActivityContext)context);

                string mailfolder = this.Foldername.Get((ActivityContext)context);

                string subject = this.Subject.Get((ActivityContext)context);

                string body = this.Body.Get((ActivityContext)context);

                string sender = this.Sender.Get((ActivityContext)context);

                string receipent = this.Receipent.Get((ActivityContext)context);

                string fromdate = this.FromDate.Get((ActivityContext)context);

                string todate = this.ToDate.Get((ActivityContext)context);

                string sCriteria;



                try
                {
                    outlookApp = new Outlook.Application();
                    outlookNameSpace = outlookApp.GetNamespace("mapi");


                    outlookNameSpace.Logon(Missing.Value, Missing.Value, false, true);
                }
                catch (COMException e1)
                {
                    throw new COMException("Exception caught: {0}", e1);
                }

                try
                {
                    referencedFolder = outlookNameSpace.Folders[account];
                }
                catch (COMException e1)
                {
                    throw new COMException("Exception caught: {0}", e1);
                }

                if (mailfolder.Contains("\\"))
                {
                    string[] folderarray = mailfolder.Split('\\');
                    try
                    {
                        foreach (var item in folderarray)
                        {
                            referencedFolder = referencedFolder.Folders[item];
                        }
                    }
                    catch (System.Runtime.InteropServices.COMException e1)
                    {

                        if (e1.Message.Contains("An object could not be found"))
                            throw new COMException("Exception caught: '" + mailfolder + "' Folder not found");

                        else
                            throw new COMException("Exception caught: {0}", e1);


                    }
                    finally
                    {
                        // statements to be executed
                    }

                }

                else
                    try
                    {

                        referencedFolder = outlookNameSpace.Folders[account].Folders[mailfolder];
                    }
                    catch (System.Runtime.InteropServices.COMException e1)
                    {
                        if (e1.Message.Contains("An object could not be found"))
                            throw new COMException("Exception caught: '" + mailfolder + "' Folder not found");

                        else
                            throw new COMException("Exception caught: {0}", e1);
                    }
                    finally
                    {
                        // statements to be executed
                    }


                //get all the items of specifed mail folder.
                items = (Outlook.Items)referencedFolder.Items;
                //items.Sort("[ReceivedTime]", true);



                if (Unread == true)
                {
                    items = items.Restrict("[Unread]=true");

                }
                if (subject != null)
                {
                    if (ExactMatch_Subject)
                    {
                        sCriteria = "[Subject] = '" + subject + "'";
                    }
                    else
                    {
                        sCriteria = @"@SQL=(""urn:schemas:httpmail:subject"" LIKE '%" + subject + @"%')";
                    }
                    items = items.Restrict(sCriteria);

                }

                //Filter for date
                try
                {
                    if (todate != null)
                    {
                        DateTime enddate;

                        enddate = DateTime.Parse(todate);


                        if (enddate.TimeOfDay.TotalSeconds == 0)
                        {
                            todate = todate + " 23:59:59";
                        }

                    }

                    if (fromdate != null && todate != null)
                    {
                        sCriteria = @"@SQL=(""urn:schemas:httpmail:datereceived"" >= '" + DateTime.Parse(fromdate).ToUniversalTime() + @"' and ""urn:schemas:httpmail:datereceived"" <= '" + DateTime.Parse(todate).ToUniversalTime() + "')";
                        items = items.Restrict(sCriteria);

                    }
                    else if (fromdate != null && todate == null)
                    {
                        sCriteria = @"@SQL=(""urn:schemas:httpmail:datereceived"" >= '" + DateTime.Parse(fromdate).ToUniversalTime() + @"')";
                        items = items.Restrict(sCriteria);

                    }
                    else if (fromdate == null && todate != null)
                    {
                        sCriteria = @"@SQL=(""urn:schemas:httpmail:datereceived"" <= '" + DateTime.Parse(todate).ToUniversalTime() + "')";
                        items = items.Restrict(sCriteria);

                    }
                }
                catch (System.Exception ex)
                {
                    throw new System.FormatException("Exception encountered in converting specified input to datetime format. Exception is " + ex);
                }
                if (body != null)
                {

                    sCriteria = @"@SQL=(""urn:schemas:httpmail:textdescription"" LIKE '%" + body + @"%')";


                    items = items.Restrict(sCriteria);


                }


                mailobj = items.GetFirst();
                while (mailobj != null)
                {



                    if (mailobj is Outlook.MailItem)
                    {
                        oitem = (Outlook.MailItem)mailobj;

                        //Mark as Read
                        if (MarkAsRead)
                        {
                            if (oitem.UnRead)
                            {
                                oitem.UnRead = false;
                                oitem.Save();
                            }
                        }

                        MailMessage mailMessage = new MailMessage();
                        mailMessage.From = new MailAddress(oitem.SendUsingAccount.SmtpAddress);
                        mailMessage.Body = oitem.Body;
                        mailMessage.Headers.Add("Date", oitem.ReceivedTime.ToString());
                        mailMessage.Subject = oitem.Subject;

                        if (oitem.Recipients != null)
                        {
                            Outlook.Recipients receipents = oitem.Recipients;

                            for (int recpCount = 1; recpCount <= oitem.Recipients.Count; recpCount++)
                            {
                                Outlook.Recipient recipient = oitem.Recipients[recpCount];

                                switch (recipient.AddressEntry.Type)
                                {
                                    case "EX":
                                        var exchangeUser = recipient.AddressEntry.GetExchangeUser();
                                        if (exchangeUser != null)
                                        {
                                            if (exchangeUser.PrimarySmtpAddress != null)
                                                mailMessage.To.Add(exchangeUser.PrimarySmtpAddress);
                                        }

                                        break;

                                    case "SMTP":
                                        if (recipient.AddressEntry.Address != null)
                                            mailMessage.To.Add(recipient.AddressEntry.Address);
                                        break;
                                }
                            }
                        }



                        //assign sender
                        if (oitem.Sender != null)
                        {
                            if (oitem.Sender.AddressEntryUserType == Outlook.OlAddressEntryUserType.olExchangeUserAddressEntry || oitem.Sender.AddressEntryUserType == Outlook.OlAddressEntryUserType.olExchangeRemoteUserAddressEntry)
                            {
                                Outlook.ExchangeUser exchUser = oitem.Sender.GetExchangeUser();
                                if (exchUser != null)
                                {
                                    if (exchUser.PrimarySmtpAddress != null)
                                        mailMessage.Sender = new MailAddress(exchUser.PrimarySmtpAddress);
                                }
                            }
                            else
                            {
                                if (oitem.SenderEmailAddress != null)
                                    mailMessage.Sender = new MailAddress(oitem.SenderEmailAddress);

                            }
                        }

                        ListRetrievedMailMessage.Add(mailMessage);
                    }
                    mailobj = items.GetNext();
                }


                List<MailMessage> FilteredListRetrievedMailMessage = new List<MailMessage>();



                if (receipent != null)
                {
                    MailAddress receipentMailAddress = new MailAddress(receipent);
                    FilteredListRetrievedMailMessage = ListRetrievedMailMessage.Where(item => item.To != null).ToList();
                    FilteredListRetrievedMailMessage = FilteredListRetrievedMailMessage.Where(item => item.To.Contains(receipentMailAddress)).ToList();
                    MailMessages.Set((ActivityContext)context, FilteredListRetrievedMailMessage);
                }


                if (sender != null)
                {
                    FilteredListRetrievedMailMessage = ListRetrievedMailMessage.Where(item => item.Sender != null).ToList();
                    FilteredListRetrievedMailMessage = FilteredListRetrievedMailMessage.Where(item => item.Sender.Address == sender).ToList();
                    MailMessages.Set((ActivityContext)context, FilteredListRetrievedMailMessage);
                }

                if (receipent == null && sender == null)
                {
                    MailMessages.Set((ActivityContext)context, ListRetrievedMailMessage);
                }



            }
            catch (COMException ex)
            {
                throw new COMException("Exception caught: {0}", ex);
            }
            catch (ArgumentException ex)
            {
                throw new COMException("Exception caught: {0}", ex);
            }
            catch (NullReferenceException ex)
            {
                throw new COMException("Exception caught: {0}", ex);
            }
            finally
            {
                ReleaseComObject(outlookNameSpace);
                ReleaseComObject(outlookApp);
                ReleaseComObject(referencedFolder);
                ReleaseComObject(items);
                ReleaseComObject(oitem);
                ReleaseComObject(mailobj);

            }

        }
        private static void ReleaseComObject(object obj)
        {
            if (obj != null)
            {
                Marshal.ReleaseComObject(obj);
                obj = null;
            }
        }
    }
}
